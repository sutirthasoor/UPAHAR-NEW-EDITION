package com.upahar.user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
